package algoritmos;
import item.Item;
import user.userManager;
import item.ItemManager;
import java.util.*;

interface RecommendationSystem {

}
