# PROP - SISTEMA RECOMANADOR

**Grup 12 - subgrup-prop1.3**

## Components del grup:

* Blavia Cañet, Pol
* Choudhry, Aftab Ahmed 
* Granero I Martí, Marta
* Umbert Bosch, Miquel 

## Adreça de correu de cada integrant:

* pol.blavia@estudiantat.upc.edu
* aftab.ahmed.choudhry@estudiantat.upc.edu
* marta.granero.i@estudiantat.upc.edu
* miquel.umbert.bosch@estudiantat.upc.edu


